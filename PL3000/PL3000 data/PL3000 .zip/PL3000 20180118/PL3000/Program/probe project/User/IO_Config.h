#ifndef __IO_CONFIG_H
#define __IO_CONFIG_H

#include "SN8F5702.h"


#define SET_SET_IO_LOW(pin)						{pin = 0;}
#define SET_SET_IO_HIGH(pin)          {pin = 1;}

#endif