#ifndef __INIT_H
#define __INIT_H

#include "SN8F5702.H"


void Init_Fun(void);

#endif
