#ifndef __MAIN_H
#define __MAIN_H

#include "SN8F5702.H"
#include "UART.h"
#include "init.h"
#include "Error_Check.h"
#include "protocol.h"
#include "key.h"

#endif
