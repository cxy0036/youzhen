#ifndef __FLASH_TIMES_H
#define __FLASH_TIMES_H

void Get_Flash_Times(void);
void Get_Flash_Times_Level(void);
void Get_Skin_Color(void);
//void Flash_Times_LED_Indicator(void);

#endif
