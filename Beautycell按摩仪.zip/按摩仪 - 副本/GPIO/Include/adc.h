#ifndef __ADC_H__
#define ADC0   Enable_ADC_AIN0
#define ADC1   Enable_ADC_AIN1
#define ADC2   Enable_ADC_AIN2
#define ADC3   Enable_ADC_AIN3
#define ADC4   Enable_ADC_AIN4
#define ADC5   Enable_ADC_AIN5
#define ADC6   Enable_ADC_AIN6
#define ADC7   Enable_ADC_AIN0
#define MODE_KEY   P05_Input_Mode
uint16_t Bat_Measure(void);
#endif