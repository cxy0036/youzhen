#ifndef __PWM_H__
 void pwm_init(void); 
 void pwm_start(void); 
 void pwm_stop(void);
 void voltage1(void);
 void voltage2(void);
 void voltage3(void);
 void voltage4(void);
 void moto_run(void);
 void moto_stop(void);
#endif